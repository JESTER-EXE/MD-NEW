const config = require('../settings')
const os = require('os')
const fs = require('fs')
const l = console.log
const { cmd, commands } = require('./lib/command')
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, Func, fetchJson} = require('../lib/functions')
let cap = '👨‍💻 𝚁𝙰𝙽𝚄 ᴍᴅ ʙʏ 𝙲𝚁𝙳 ᴛᴇᴀᴍ 👨‍💻'
const si = require('systeminformation')



//---------------------------------------------------------------------------
if (config.COMMAND_TYPE === 'button') {
//---------------------------------------------------------------------------



cmd({
    pattern: "menu",
    react: "📖",
    alias: ["panel", "list", "commands", "cmd"],
    desc: "Get bot\'s command list.",
    category: "other",
    use: '.menu',
    filename: __filename
}, async (conn, mek, m, { from, prefix, pushname, reply }) => {
    try {
        let wm = `👨‍💻 𝚁𝙰𝙽𝚄 ᴍᴅ ʙʏ 𝙲𝚁𝙳 ᴛᴇᴀᴍ 👨‍💻`
        if (os.hostname().length == 12) hostname = 'replit'
        else if (os.hostname().length == 36) hostname = 'heroku'
        else if (os.hostname().length == 8) hostname = 'koyeb'
        else hostname = os.hostname()
        let monspace = '```'
            const MNG = `❖👨‍💻 𝚁𝙰𝙽𝚄 ᴍᴅ ʙʏ 𝙲𝚁𝙳 ᴛᴇᴀᴍ 👨‍💻❖
	    
${monspace}👋 Hello ${pushname}${monspace}

╭───═❮ *ᴍᴇɴᴜ ʟɪsᴛ* ❯═───❖
│ *🚀𝙑𝙀𝙍𝙎𝙄𝙊𝙉:* ${require("../package.json").version}
│ *⌛𝙈𝙀𝙈𝙊𝙍𝙔:* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
│ *🕒𝙍𝙐𝙉𝙏𝙄𝙈𝙀:* ${runtime(process.uptime())}
│ *📍𝙋𝙇𝘼𝙏𝙁𝙊𝙍𝙈:* ${hostname}
╰━━━━━━━━━━━━━━━┈⊷`
            const categories = [];
        const categoryMap = new Map();

        for (let i = 0; i < commands.length; i++) {
            const cmd = commands[i];
            if (!cmd.dontAddCommandList && cmd.pattern !== undefined) {
                const category = cmd.category.toUpperCase();
                if (!categoryMap.has(category)) {
                    categories.push(category);
                    categoryMap.set(category, []);
                }
                categoryMap.get(category).push(cmd.pattern);
            }
        }

        const rows = []
        for (const category of categories) {
            rows.push({
                header: '',
                title: `${category} MENU`,
                description: '',
                id: `${prefix}category ${category}`
            })
        }

        let buttons = [{
                name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: config.BTN,
                        url: config.BTNURL,
                        merchant_url: config.BTNURL
                }),
            },
            {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: 'Select a SubMenu',
                    sections: [{
                        title: 'Please select a SubMenu',
                        highlight_label: '𝚁𝙰𝙽𝚄-ᴍᴅ',
                        rows: rows
                    }]
                }),
            }
        ]

        let opts = {
            image: config.LOGO,
            header: '',
            footer: wm,
            body: MNG
        }

        return await conn.sendButtonMessage(from, buttons, m, opts)
    } catch (e) {
        reply('*Error !!*')
        console.log(e)
    }
})



cmd({
    pattern: "menu2",
    react: "📂",
    alias: ["help"],
    desc: "Get bot\'s command list.",
    category: "main",
    use: '.menu',
    filename: __filename
},
async(conn, mek, m,{from, prefix, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
    let menuc1 = ``
for (let i=0;i<commands.length;i++) { 
if(commands[i].category === 'download'){
if(!commands[i].dontAddCommandList){
menuc1 += `*◉ :* ${commands[i].pattern}\n`
}}};

let menuc2 = ``
for (let i=0;i<commands.length;i++) { 
  if(commands[i].category === 'search'){
  if(!commands[i].dontAddCommandList){
  menuc2 += `*◉ :* ${commands[i].pattern}\n`
}}};

let menuc3 = ``
for (let i=0;i<commands.length;i++) { 
if(commands[i].category === 'convert'){
  if(!commands[i].dontAddCommandList){
    menuc3 += `*◉ :* ${commands[i].pattern}\n`
}}};

let menuc4 = ``
for (let i=0;i<commands.length;i++) { 
if(commands[i].category === 'logo'){
  if(!commands[i].dontAddCommandList){
menuc4 += `*◉ :* ${commands[i].pattern}\n`
}}};

let menuc5 = ``
for (let i=0;i<commands.length;i++) { 
if(commands[i].category === 'main'){
  if(!commands[i].dontAddCommandList){
menuc5 += `*◉ :* ${commands[i].pattern}\n`
}}};

let menuc6 = ``
for (let i=0;i<commands.length;i++) { 
if(commands[i].category === 'group'){
if(!commands[i].dontAddCommandList){
  menuc6 += `*◉ :* ${commands[i].pattern}\n`
}}};

let menuc7 = ``
for (let i=0;i<commands.length;i++) { 
if(commands[i].category === 'bug'){
if(!commands[i].dontAddCommandList){
  menuc7 += `*◉ :* ${commands[i].pattern}\n`
}}};

let menuc8 = ``
for (let i=0;i<commands.length;i++) { 
if(commands[i].category === 'movie'){
if(!commands[i].dontAddCommandList){
  menuc8 += `*◉ :* ${commands[i].pattern}\n`
}}};	

let menuc9 = ``
for (let i=0;i<commands.length;i++) { 
if(commands[i].category === 'other'){
if(!commands[i].dontAddCommandList){
  menuc9 += `*◉ :* ${commands[i].pattern}\n`
}}};
     
let menumg = `*Hellow👸* ${pushname}

*╭─     ᴄᴏᴍᴍᴀɴᴅꜱ ᴘᴀɴᴇʟ*
*│🕵️‍♂️ 𝘙𝘶𝘯 𝘛𝘪𝘮𝘦 -* ${runtime(process.uptime())} 
*│🕵️‍♂️ 𝘙𝘢𝘮 𝘜𝘴𝘦 -* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
*╰──────────●●►*
*👸 ＲＡＮＵ 𝘔𝘥 𝘊𝘰𝘮𝘮𝘢𝘮𝘥 𝘗𝘢𝘯𝘦𝘭*
> *╭──────────●●►*
> *│🧙‍♂️ DOWNLOAD COMMANDS*
> *│   ───────*

${menuc1}*╰───────────●●►*
> *╭──────────●●►*
> *│🧙‍♂️ SEARCH COMMANDS*
> *│   ───────*

${menuc2}*╰───────────●●►*

> *╭──────────●●►*
> *│🧙‍♂️ CONVERT COMMANDS*
> *│   ───────*

${menuc3}*╰───────────●●►*

> *╭──────────●●►*
> *│🧙‍♂️ LOGO COMMANDS*
> *│   ───────*

${menuc4}*╰───────────●●►*

> *╭──────────●●►*
> *│🧙‍♂️ MAIN COMMANDS*
> *│   ───────*

${menuc5}*╰───────────●●►*

> *╭──────────●●►*
> *│🧙‍♂️ GROUP COMMANDS*
> *│   ───────*

${menuc6}*╰───────────●●►*

> *╭──────────●●►*
> *│🧙‍♂️ BUG COMMANDS*
> *│   ───────*

${menuc7}*╰───────────●●►*

> *╭──────────●●►*
> *│🧙‍♂️ MOVIE COMMANDS*
> *│   ───────*

${menuc8}*╰───────────●●►*

> *╭──────────●●►*
> *│🧙‍♂️ OTHER COMMANDS*
> *│   ───────*

${menuc9}*╰───────────●●►*	

👨‍💻 𝚁𝙰𝙽𝚄 ᴍᴅ ʙʏ 𝚁𝙴𝙳 𝙳𝚁𝙰𝙶𝙾𝙽 👨‍💻`	
      
let wm = `👨‍💻 𝚁𝙰𝙽𝚄 ᴍᴅ ʙʏ 𝙲𝚁𝙳 ᴛᴇᴀᴍ 👨‍💻`
             let buttons = [{
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: config.BTN,
                        url: config.BTNURL,
                        merchant_url: config.BTNURL
                    }),
                }
            ]
            let message = {
                image: config.LOGO,
                header: '',
                footer: config.FOOTER,
                body: menumg

            }
            return await conn.sendButtonMessage(from, buttons, m, message)
} catch (e) {
  reply('*ERROR !!*')
  console.log(e)
}
})



cmd({
    pattern: "category",
    dontAddCommandList: true,
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        let wm = '*𝚁𝙰𝙽𝚄 ᴍᴅ ᴡʜᴀᴛꜱᴀᴘᴘ ᴜꜱᴇʀ ʙᴏᴛ*\n*ᴛʜᴇ ᴛᴇᴀᴍ • 𝚁𝙴𝙳 𝙳𝚁𝙰𝙶𝙾𝙽*'
        const category = q.trim().toUpperCase();
        let commandList = `*◈╾──────${category} SUB COMMAND LIST──────╼◈*\n\n> Select you want command type and enjoy vajira md whatsapp bot 👨‍💻\n\n`;

        for (let i = 0; i < commands.length; i++) {
            const cmd = commands[i];
            if (cmd.category.toUpperCase() === category) {
                commandList += `╭────────●●►\n│ • *${cmd.pattern}* \n╰────────────────────●●►\n`;
            }
        }

        commandList += `\n⭓ *Total Commands List ${category}*: ${commands.filter(cmd => cmd.category.toUpperCase() === category).length}\n\n${wm}`

        //await conn.sendMessage(from, { text: commandList }, { quoted: mek });
        await conn.sendMessage(from, {
text: commandList,
  contextInfo: {
    mentionedJid: [ '' ],
    groupMentions: [],
    forwardingScore: 1111,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: '120363401830115733@newsletter',
      serverMessageId: 127
    },
externalAdReply: { 
title: '👨‍💻 𝚁𝙰𝙽𝚄 ᴍᴅ ʙʏ 𝙲𝚁𝙳 ᴛᴇᴀᴍ 👨‍💻',
body: 'ᴀ ꜱɪᴍᴘʟᴇ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ',
mediaType: 1,
sourceUrl: "https://whatsapp.com/channel/0029VbBIIzKJP21DcJla2S1s" ,
thumbnailUrl: config.LOGO ,
renderLargerThumbnail: true,
showAdAttribution: false
}
}}, { quoted: mek})
    } catch (e) {
        reply('*Error !!*')
        console.log(e)
    }
})


//==================================================================	


        






cmd({
        pattern: "alive",
        react: "🍬",
        desc: "Check bot online or no.",
        category: "main",
        use: '.alive',
        filename: __filename
    },
    async(conn, mek, m,{from, prefix, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
            if (os.hostname().length == 12) hostname = 'replit'
            else if (os.hostname().length == 36) hostname = 'heroku'
            else if (os.hostname().length == 8) hostname = 'koyeb'
            else hostname = os.hostname()
            let monspace = '```'
            const sssf = `${monspace}👋 Hello ${pushname} I'm alive now${monspace}

*👾 Im 𝐑𝐀𝐍𝐔-MD whatsapp bot*
    
> *Version:* ${require("../package.json").version}
> *Memory:* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
> *Runtime:* ${runtime(process.uptime())}
> *Platform:* ${hostname}

🐼This is the result of our teams hard work and our Red Dragon team owns the bots rights and code rights. Therefore, you have no chance to change and submit our bot under any circumstances And 100 Commands And logo, thumbnail,banner Maker Commands Ai Chatbot feathers On Our Bot
                    	    
*🍭 Have A Nice Day 🍭*`

            let buttons = [{
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: config.BTN,
                        url: config.BTNURL,
                        merchant_url: config.BTNURL
                    }),
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Get Menu",
                        id: `${prefix}menu`
                    }),
                }
            ]
            let opts = {
                image: config.LOGO,
                header: '',
                footer: config.FOOTER,
                body: sssf

            }
            return await conn.sendButtonMessage(from, buttons, m, opts)
        } catch (e) {
            reply('*Error !!*')
            console.log(e)
        }
    })





cmd({
        pattern: "sc",
        react: "🗃️",
        alias: ["repo", "script", "status"],
        desc: "Get bot\'s command list.",
        category: "main",
        use: '.sc',
        filename: __filename
    },
    async(conn, mek, m,{from, prefix, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
            if (os.hostname().length == 12) hostname = 'replit'
            else if (os.hostname().length == 36) hostname = 'heroku'
            else if (os.hostname().length == 8) hostname = 'koyeb'
            else hostname = os.hostname()
            let monspace = '```'
            const MNG = `${monspace}👋 Hello ${pushname}${monspace}

*👾 𝐑𝐀𝐍𝐔-MD commands menu...*
  
> *Version:* ${require("../package.json").version}
> *Memory:* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
> *Runtime:* ${runtime(process.uptime())}
> *Platform:* ${hostname}
  *𝐑𝐀𝐍𝐔 MD WHATSAPP USER BOT* 💫

                     *OUR MISSION*

🐼This is the result of our teams hard work and our Red Dragon team owns the bots rights and code rights. Therefore, you have no chance to change and submit our bot under any circumstances And 100 Commands And logo, thumbnail,banner Maker Commands Ai Chatbot feathers On Our Bot


🐼 The main hope of creating this bot is to take full advantage of the WhatsApp app and make its work easier

`
            let buttons = [{
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: 'YT CHANNEL',
                        url: 'https://youtube.com/@srilankatechnologyboys6775?si=YjBbbRDEpg1YGAtk',
                        merchant_url: 'https://youtube.com/@srilankatechnologyboys6775?si=YjBbbRDEpg1YGAtk'
                    }),
                },
	        {	 
		name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: 'OWNER FB PAGE',
                        url: 'https://www.facebook.com/profile.php?id=100071777656148&mibextid=rS40aB7S9Ucbxw6v',
                        merchant_url: 'https://www.facebook.com/profile.php?id=100071777656148&mibextid=rS40aB7S9Ucbxw6v'
                   }),	
		},
		{	 
		name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: 'MY WA NUMBER',
                        url: 'https://wa.me/94783462955',
                        merchant_url: 'https://wa.me/94783462955'
                   }),	
		},	   
		{	 
		name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: 'MY WA CHANNEL',
                        url: 'https://whatsapp.com/channel/0029VbBIIzKJP21DcJla2S1s',
                        merchant_url: 'https://whatsapp.com/channel/0029VbBIIzKJP21DcJla2S1s'
                   }),	
		},	
                {	 
		name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: 'MY GITHUB',
                        url: 'https://github.com/rikkqa43',
                        merchant_url: 'https://github.com/rikkqa43'
                   }),	
		},
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Get Menu",
                        id: `${prefix}menu`
                    }),
                }
            ]
            let opts = {
                image: config.LOGO,
                header: '',
                footer: config.FOOTER,
                body: MNG

            }
            return await conn.sendButtonMessage(from, buttons, m, opts)
        } catch (e) {
            reply('*Error !!*')
            console.log(e)
        }
    })




//---------------------------------------------------------------------------
}
//---------------------------------------------------------------------------


cmd({
    pattern: "system",
    react: "🖥️",
    alias: ["s_info"],
    desc: "To Check bot\'s System information",
    category: "main",
    use: '.system',
    filename: __filename
},
async(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const ccp = await si.cpu()
const cinfo = await si.version()
let timee = await si.time()
const plat = os.hostname()
let data = await fetchJson('https://gist.github.com/VajiraTech/c4f2ac834de5c45b3a8de8e2d165f973/raw')

if ( plat.length > 15 ) {
const infomsg = `🖥️  *𝐑𝐀𝐍𝐔-MD 1.0 SYSTEM INFORMATIONS*  🖥️

🤖  *_Bot's System informations_*

1.  _Runtime -: ${runtime(process.uptime())}_
2.  _Ram Usage -: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB_
3.  _Bot Version -: ${data.version} Stable_

📶  *_Server System informations_*

1.  _Platform : Heroku_
2.  _Running OS : ${os.platform()}_
3.  _CPU Manufacture  -: ${ccp.manufacturer}_
4.  _CPU Brand -: ${ccp.brand}_
5.  _CPU Speed -: ${ccp.speed}_

⚙️  *_System Data Collector Engine_*

1. _Engine Version -: ${cinfo}_

💻  *_Running Server's information_*

1. _Server Time Zone -: ${timee.timezone}_
2. _Time Zone Name -: ${timee.timezoneName}_`
return await conn.sendMessage(from , { text: infomsg  }, { quoted: mek } )

}


const infomsg = `🖥️  *𝐑𝐀𝐍𝐔 MD  1.0 SYSTEM INFORMATIONS*  🖥️

🤖  *_Bot's System informations_*

1.  _Runtime -: ${runtime(process.uptime())}_
2.  _Ram Usage -: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB_
3.  _Bot Version -: ${data.version} Stable_

📶  *_Server System informations_*

1.  _Platform : ${plat}_
2.  _Running OS : ${os.platform()}_
3.  _CPU Manufacture  -: ${ccp.manufacturer}_
4.  _CPU Brand -: ${ccp.brand}_
5.  _CPU Speed -: ${ccp.speed}_

⚙️  *_System Data Collector Engine_*

1. _Engine Version -: ${cinfo}_

💻  *_Running Server's information_*

1. _Server Time Zone -: ${timee.timezone}_
2. _Time Zone Name -: ${timee.timezoneName}_`
 await conn.sendMessage(from , { text: infomsg  }, { quoted: mek } )

}catch (e) {
reply('*Error !!*')
l(e)
}
})
			
